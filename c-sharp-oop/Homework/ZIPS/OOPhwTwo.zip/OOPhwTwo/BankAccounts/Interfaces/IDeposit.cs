﻿namespace BankAccounts.Interfaces
{
    public interface IDeposit
    {
        void DepositFunds(decimal amount);
    }
}
