﻿namespace BankAccounts.Interfaces
{
    public interface IWithdraw
    {
        void WithdrawFunds(decimal amount);
    }
}
