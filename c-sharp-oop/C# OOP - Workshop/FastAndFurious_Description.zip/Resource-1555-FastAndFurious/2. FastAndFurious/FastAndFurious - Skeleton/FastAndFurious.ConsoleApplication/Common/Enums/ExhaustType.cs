﻿namespace FastAndFurious.ConsoleApplication.Common.Enums
{
    public enum ExhaustType
    {
        NotSet = 0,
        NickelChromePlated,
        StainlessSteel,
        CeramicCoated
    }
}
