function solve() {
	// Your classes

	return {
		createApp(name, description, version, rating) {
			// returns a new App object
		},
		createStore(name, description, version, rating) {
			// returns a new Store object
		},
		createDevice(hostname, apps) {
			// returns a new Device object
		}
	};
}

// Submit the code above this line in bgcoder.com
module.exports = solve;
