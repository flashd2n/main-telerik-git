﻿namespace BunniesTask
{
    public enum FurType
    {
        NotFluffy, ALittleFluffy, Fluffy, FluffyToTheLimit
    }
}
