﻿namespace ProjectManager.Framework.Core.Common.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
