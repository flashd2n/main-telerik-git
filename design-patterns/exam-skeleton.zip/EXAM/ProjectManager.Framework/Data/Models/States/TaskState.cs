﻿namespace ProjectManager.Framework.Data.Models.States
{
    public enum TaskState
    {
        Pending = 0,
        InProgress = 1,
        Done = 2
    }
}
