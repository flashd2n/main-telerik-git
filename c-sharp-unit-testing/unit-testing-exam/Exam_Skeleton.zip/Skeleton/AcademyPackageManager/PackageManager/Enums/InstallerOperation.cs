﻿namespace PackageManager.Enums
{
    public enum InstallerOperation
    {
        Install = 0,
        Uninstall = 1,
        Update = 2
    }
}
